{-# LANGUAGE OverloadedStrings #-}

module Main where

import Web.Scotty
import qualified Data.Text.Lazy as T
import qualified Data.Text.Lazy.IO as TIO
import Network.Wai.Middleware.Static
import Web.Scotty (pathParam, formParam, queryParam)
import Network.Wai.Middleware.RequestLogger (logStdoutDev)
import Network.HTTP.Types.Status (status404)
import Data.Aeson (object, (.=))
import System.IO (BufferMode(LineBuffering), hSetBuffering, stdout)

-- Beach safety tips data
data SafetyTip = SafetyTip
    { tipTitle :: T.Text
    , tipContent :: [T.Text]
    }

-- Our collection of beach safety tips
safetyTips :: [(String, SafetyTip)]
safetyTips =
    [ ("general", SafetyTip "General Safety Guidelines"
        [ "Always swim in designated swimming areas."
        , "Follow the instructions of lifeguards."
        , "Never swim alone."
        ])
    , ("rip", SafetyTip "Rip Current Awareness"
        [ "Look for signs of rip currents (discolored water, debris moving away from shore)."
        , "If caught in a rip current, swim parallel to the shore."
        , "Don't fight the current; instead, stay calm and signal for help."
        ])
    , ("weather", SafetyTip "Weather Conditions"
        [ "Check weather forecasts before going to the beach."
        , "Avoid swimming during storms or when lightning is present."
        , "Be aware of sudden weather changes."
        ])
    , ("marine", SafetyTip "Marine Life Precautions"
        [ "Avoid touching or stepping on marine animals."
        , "Watch out for jellyfish and other potentially dangerous creatures."
        , "Seek medical help if stung or bitten."
        ])
    ]

-- Rendered CLI-style menu
getMenu :: T.Text
getMenu = T.unlines
    [ "🏖️ Beach Safety Tips Menu:"
    , "1. General Safety Guidelines"
    , "2. Rip Current Awareness"
    , "3. Weather Conditions"
    , "4. Marine Life Precautions"
    , "5. Exit"
    ]

main :: IO ()
main = do
    -- Set buffer mode to ensure console output is displayed immediately
    hSetBuffering stdout LineBuffering
    putStrLn "Starting Beach Safety Server on http://localhost:3000"
    
    scotty 3000 $ do
        -- Add middleware for static files and logging
        middleware logStdoutDev
        middleware $ staticPolicy (addBase "static")

        -- Simulated CLI menu
        get "/" $ do
            result <- liftIO $ TIO.readFile "static/menu.html"
            html result
        

        -- Full HTML welcome page
        get "/welcome" $ do
            -- Use a more robust approach to file reading with error handling
            result <- liftIO $ do
                putStrLn "Attempting to read welcome.html"
                TIO.readFile "static/welcome.html"
            html result
            
        -- API endpoint for safety tips
        get "/api/tips/:topic" $ do
            topic <- param "topic"
            case lookup topic safetyTips of
                Just tip -> json $ object
                    [ "title" .= tipTitle tip
                    , "content" .= tipContent tip
                    ]
                Nothing -> do
                    status status404
                    json $ object
                        [ "error" .= ("Topic not found: " ++ topic)
                        ]
                        
        -- Error handling
        notFound $ do
            html "<h1>404 - Page Not Found</h1><p>Sorry, the page you're looking for doesn't exist.</p>"